# wa-starter

This repo contains code to input phone number with country code that translates into a WhatsApp link for starting a WhatsApp conversation.

The interesting part is that you can paste a phone number that gets parsed
